// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef EXPAT_STATIC_PRIVATE_H
#define EXPAT_STATIC_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"0.1.1.1"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	1
#define VER_BUILD	1
#define COMPANYNAME	""
#define FILEVERSION	"0.1"
#define FILEDESCRIPTION	"Developed using the Dev-C++ IDE"
#define INTERNALNAME	""
#define LEGALCOPYRIGHT	""
#define LEGALTRADEMARKS	""
#define ORIGINALFILENAME	"expat_static.exe"
#define PRODUCTNAME	"expat_static"
#define PRODUCTVERSION	"0.1"

#endif //EXPAT_STATIC_PRIVATE_H
