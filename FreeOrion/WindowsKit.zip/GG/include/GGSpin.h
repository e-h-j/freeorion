/* GG is a GUI for SDL and OpenGL.
   Copyright (C) 2003 T. Zachary Laine

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1
   of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
    
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA

   If you do not wish to comply with the terms of the LGPL please
   contact the author as other terms are available for a fee.
    
   Zach Laine
   whatwasthataddress@hotmail.com */

/* $Header: /cvsroot/gigi/GG/include/GGSpin.h,v 1.4 2003/07/25 22:44:24 tzlaine Exp $ */

#ifndef _GGSpin_h_
#define _GGSpin_h_

#ifndef _GGEdit_h_
#include "GGEdit.h"
#endif

#ifndef _GGButton_h_
#include "GGButton.h"
#endif

#ifndef _GGApp_h_
#include "GGApp.h"
#endif

#ifndef _GGDrawUtil_h_
#include "GGDrawUtil.h"
#endif

#include <limits>

namespace GG {

// forward declaration of details::mod and details::div
namespace details {
template <class T> T mod(T, T);
template <class T> T div(T, T);
}

/** a spin box control.  This control class is templated so that arbitrary data types can be used with Spin.  All the 
    built-in numeric types are supported by the code here.  If you want to use some other type, such as an enum type,
    you need to define operator+(), operator-(), and template specializations of details::mod() and details::div().  
    Spin controls are optionally directly editable by the user.  When the user inputs a value that is not valid for the
    Spin's parameters (not on a step boundary, or outside the allowed range), the input gets locked to the nearest
    valid value.  The user is responsible for selecting a min, max, and step size that make sense.  For instance, 
    min = 0, max = 4, step = 3 may produce odd results if the user increments all the way to the top, then back down,
    to produce the sequence 0, 3, 4, 1, 0.  To avoid this, choose the values so that (max - min) mod step == 0.  It is
    possible to provide custom buttons for a Spin to use; if you choose to add custom buttons, make sure they look 
    alright at arbitrary sizes, and note that Spin buttons are always H wide by H/2 tall, where H is the height of 
    the Spin, less the thickness of the Spin's border.  Since spin is a templated class, it is impossible to add 
    every possible instantiation to the app's XMLObjectFactory.  So if you want Spin controls to be automatically
    loaded in your application, and you are instantiating them with some type other than Spin<int> or Spin<double>, 
    you need to add them to the app yourself, using XMLTypeName().  See GG::App::AddWndGenerator() and 
    GG::XMLObjectFactory for details on this topic in general, and see AppImplData::AppImplData() in GGApp.cpp for 
    example code for adding Spins to the app's object factory.*/
template <class T>
class Spin : public Control
{
public:
    using Wnd::SizeMove;

    /** \name Signal Types */ //@{
    // HACK! have to use the boost.signals portable syntax, since GCC 3.2 doesn't like "boost::signal<void (T)>"
    typedef boost::signal1<void, T> ValueChangedSignalType;  ///< emitted whenever the value of the Spin has changed
    //@}

    /** \name Slot Types */ //@{
    typedef typename ValueChangedSignalType::slot_type ValueChangedSlotType;   ///< type of functor(s) invoked on a ValueChangedSignalType
    //@}

    /** \name Structors */ //@{
    /** ctor*/
    Spin(int x, int y, int w, int h, T value, T step, T min, T max, bool edits, const shared_ptr<Font>& font, Clr color, 
         Clr text_color = CLR_BLACK, Clr interior = CLR_ZERO, Button* up = 0, Button* down = 0, 
         Uint32 flags = CLICKABLE | DRAG_KEEPER) : 
        Control(x, y, w, h),
        m_value(value),
        m_step_size(step),
        m_min_value(min),
        m_max_value(max),
        m_editable(edits),
        m_up_bn(up),
        m_dn_bn(down),
        m_initial_depressed_area(NONE),
        m_depressed_area(NONE)
    {
        Init(font, color, text_color, interior, flags);
    }
   
    /** ctor*/
    Spin(int x, int y, int w, int h, T value, T step, T min, T max, bool edits, const string& font_filename, int pts, Clr color, 
         Clr text_color = CLR_BLACK, Clr interior = CLR_ZERO, Button* up = 0, Button* down = 0, 
         Uint32 flags = CLICKABLE | DRAG_KEEPER) : 
        Control(x, y, w, h),
        m_value(value),
        m_step_size(step),
        m_min_value(min),
        m_max_value(max),
        m_editable(edits),
        m_up_bn(up),
        m_dn_bn(down),
        m_initial_depressed_area(NONE),
        m_depressed_area(NONE)
    {
        Init(App::GetApp()->GetFont(font_filename, pts), color, text_color, interior, flags);
    }
   
    /** ctor that does not required height. Height is determined from the font and point size used.*/
    Spin(int x, int y, int w, T value, T step, T min, T max, bool edits, const shared_ptr<Font>& font, Clr color, 
         Clr text_color = CLR_BLACK, Clr interior = CLR_ZERO, Button* up = 0, Button* down = 0, 
         Uint32 flags = CLICKABLE | DRAG_KEEPER) : 
        Control(x, y, w, font->Height() + 2 * PIXEL_MARGIN, flags),
        m_value(value),
        m_step_size(step),
        m_min_value(min),
        m_max_value(max),
        m_editable(edits),
        m_up_bn(up),
        m_dn_bn(down),
        m_initial_depressed_area(NONE),
        m_depressed_area(NONE)
    {
        Init(font, color, text_color, interior, flags);
    }
   
    /** ctor that does not required height. Height is determined from the font and point size used.*/
    Spin(int x, int y, int w, T value, T step, T min, T max, bool edits, const string& font_filename, int pts, Clr color, 
         Clr text_color = CLR_BLACK, Clr interior = CLR_ZERO, Button* up = 0, Button* down = 0, 
         Uint32 flags = CLICKABLE | DRAG_KEEPER) : 
        Control(x, y, w, App::GetApp()->GetFont(font_filename, pts)->Height() + 2 * PIXEL_MARGIN),
        m_value(value),
        m_step_size(step),
        m_min_value(min),
        m_max_value(max),
        m_editable(edits),
        m_up_bn(up),
        m_dn_bn(down),
        m_initial_depressed_area(NONE),
        m_depressed_area(NONE)
    {
        Init(App::GetApp()->GetFont(font_filename, pts), color, text_color, interior, flags);
    }
   
    /** ctor that constructs an Spin object from an XMLElement. \throw std::invalid_argument May throw 
        std::invalid_argument if \a elem does not encode a Spin object*/
    Spin(const XMLElement& elem) : 
        Control(elem.Child("GG::Control")),
        m_initial_depressed_area(NONE),
        m_depressed_area(NONE)
    {
        if (elem.Tag() != XMLTypeName())
            throw std::invalid_argument("Attempted to construct a " + XMLTypeName() + " from an XMLElement that had a tag other than \"" + XMLTypeName() + "\"");

        const XMLElement* curr_elem = &elem.Child("m_value");
        m_value = lexical_cast<T>(curr_elem->Attribute("value"));
   
        curr_elem = &elem.Child("m_step_size");
        m_step_size = lexical_cast<T>(curr_elem->Attribute("value"));
   
        curr_elem = &elem.Child("m_min_value");
        m_min_value = lexical_cast<T>(curr_elem->Attribute("value"));
   
        curr_elem = &elem.Child("m_max_value");
        m_max_value = lexical_cast<T>(curr_elem->Attribute("value"));
   
        curr_elem = &elem.Child("m_editable");
        m_editable = lexical_cast<bool>(curr_elem->Attribute("value"));
   
        curr_elem = &elem.Child("m_edit");
        m_edit = new Edit(curr_elem->Child("GG::Edit"));
        if (m_editable) {
            AttachChild(m_edit);
            m_edit_connection = Connect(m_edit->FocusUpdateSignal(), &Spin::ValueUpdated, this);
        }
   
        curr_elem = &elem.Child("m_up_bn");
        Wnd* w = App::GetApp()->GenerateWnd(curr_elem->Child(0));
        if (Button* b = dynamic_cast<Button*>(w)) {
            m_up_bn.reset(b);
        } else {
            throw std::runtime_error("Spin::Spin : Attempted to use a non-Button object as the increment button for a GG::Spin.");
        }
   
        curr_elem = &elem.Child("m_dn_bn");
        w = App::GetApp()->GenerateWnd(curr_elem->Child(0));
        if (Button* b = dynamic_cast<Button*>(w)) {
            m_dn_bn.reset(b);
        } else {
            throw std::runtime_error("Spin::Spin : Attempted to use a non-Button object as the decrement button for a GG::Spin.");
        }
    }
    
    /** dtor*/
    ~Spin() {DetachChildren(); delete m_edit;}
    //@}

    /** \name Accessors */ //@{
    T     Value() const              {return m_value;}          ///< returns the current value of the control's text
    T     StepSize() const           {return m_step_size;}      ///< returns the step size of the control
    T     MinValue() const           {return m_min_value;}      ///< returns the minimum value of the control
    T     MaxValue() const           {return m_max_value;}      ///< returns the maximum value of the control
    bool  EditsAllowed() const       {return m_editable;}       ///< returns true if the spinbox can have its value typed in directly

    Clr   TextColor() const          {return m_edit->TextColor();}          ///< returns the text color
    Clr   InteriorColor() const      {return m_edit->InteriorColor();}      ///< returns the the interior color of the control
    Clr   HiliteColor() const        {return m_edit->HiliteColor();}        ///< returns the color used to render hiliting around selected text
    Clr   SelectedTextColor() const  {return m_edit->SelectedTextColor();}  ///< returns the color used to render selected text

    /** constructs an XMLElement from a Spin object*/
    virtual XMLElement XMLEncode() const
    {
        XMLElement retval(XMLTypeName());
        if (m_editable)
            const_cast<Spin*>(this)->DetachChildren();
        retval.AppendChild(Control::XMLEncode());
        if (m_editable)
            const_cast<Spin*>(this)->AttachChild(m_edit);
   
        XMLElement temp;
   
        temp = XMLElement("m_value");
        temp.SetAttribute("value", lexical_cast<string>(m_value));
        retval.AppendChild(temp);
   
        temp = XMLElement("m_step_size");
        temp.SetAttribute("value", lexical_cast<string>(m_step_size));
        retval.AppendChild(temp);
   
        temp = XMLElement("m_min_value");
        temp.SetAttribute("value", lexical_cast<string>(m_min_value));
        retval.AppendChild(temp);

        temp = XMLElement("m_max_value");
        temp.SetAttribute("value", lexical_cast<string>(m_max_value));
        retval.AppendChild(temp);
   
        temp = XMLElement("m_editable");
        temp.SetAttribute("value", lexical_cast<string>(m_editable));
        retval.AppendChild(temp);
   
        temp = XMLElement("m_edit");
        temp.AppendChild(m_edit->XMLEncode());
        retval.AppendChild(temp);
   
        temp = XMLElement("m_up_bn");
        temp.AppendChild(m_up_bn->XMLEncode());
        retval.AppendChild(temp);
   
        temp = XMLElement("m_dn_bn");
        temp.AppendChild(m_dn_bn->XMLEncode());
        retval.AppendChild(temp);

        return retval;
    }
    //@}

    /** \name Mutators */ //@{
    virtual int Render()
    {
        Clr color_to_use = Disabled() ? DisabledColor(Color()) : Color();
        Clr int_color_to_use = Disabled() ? DisabledColor(InteriorColor()) : InteriorColor();
        Pt ul = UpperLeft(), lr = LowerRight();
        BeveledRectangle(ul.x, ul.y, lr.x, lr.y, int_color_to_use, color_to_use, false, BORDER_THICK);
        if (!m_editable) {
            m_edit->OffsetMove(UpperLeft());
            m_edit->Render();
            m_edit->OffsetMove(-UpperLeft());
        }
        m_up_bn->OffsetMove(UpperLeft());
        m_dn_bn->OffsetMove(UpperLeft());
        m_up_bn->Render();
        m_dn_bn->Render();
        m_up_bn->OffsetMove(-UpperLeft());
        m_dn_bn->OffsetMove(-UpperLeft());
        return 1;
    }
   
    virtual int LButtonDown(const Pt& pt, Uint32 keys)
    {
        if (!Disabled()) {
            Pt ul = UpperLeft();
            if (m_up_bn->InWindow(pt - ul)) {
                m_initial_depressed_area = UP_BN;
                m_depressed_area = UP_BN;
                m_up_bn->SetState(Button::BN_PRESSED);
                Incr();
            } else if (m_dn_bn->InWindow(pt - ul)) {
                m_initial_depressed_area = DN_BN;
                m_depressed_area = DN_BN;
                m_dn_bn->SetState(Button::BN_PRESSED);
                Decr();
            } else {
                m_initial_depressed_area = NONE;
                m_depressed_area = NONE;
            }
        }
        return 1;
    }
   
    virtual int LDrag(const Pt& pt, const Pt& move, Uint32 keys)
    {
        if (!Disabled()) {
            Pt ul = UpperLeft();
            if (m_up_bn->InWindow(pt - ul)) {
                Incr();
            } else if (m_dn_bn->InWindow(pt - ul)) {
                Decr();
            }
        }
        return 1;
    }
   
    virtual int LButtonUp(const Pt& pt, Uint32 keys)
    {
        m_up_bn->SetState(Button::BN_UNPRESSED);
        m_dn_bn->SetState(Button::BN_UNPRESSED);
        m_initial_depressed_area = NONE;
        m_depressed_area = NONE;
        return 1;
    }
   
    virtual int LClick(const Pt& pt, Uint32 keys)      {return LButtonUp(pt, keys);}
    virtual int MouseHere(const Pt& pt, Uint32 keys)   {return LButtonUp(pt, keys);}
    virtual int MouseLeave(const Pt& pt, Uint32 keys)  {m_depressed_area = NONE; return 1;}
   
    virtual int Keypress(Key key, Uint32 key_mods)
    {
        switch (key) {
        case GGK_HOME:
            SetValue(m_min_value);
            break;
        case GGK_END:
            SetValue(m_max_value);
            break;
        case GGK_PAGEUP:
        case GGK_UP:
        case GGK_PLUS:
        case GGK_KP_PLUS:
            Incr();
            break;
        case GGK_PAGEDOWN:
        case GGK_DOWN:
        case GGK_MINUS:
        case GGK_KP_MINUS:
            Decr();
            break;
        default:
            break;
        }
        return 1;
    }

    // sizes the conrol, then resizes the Buttons and Edit as needed
    virtual void SizeMove(int x1, int y1, int x2, int y2)
    {
        Wnd::SizeMove(x1, y1, x2, y2);
        const int BN_X_POS = Width() - (Height() - 2 * BORDER_THICK) - BORDER_THICK;
        const int BN_WIDTH = Height() - 2 * BORDER_THICK;
        const int BNS_HEIGHT = BN_WIDTH; // height of BOTH buttons
        m_edit->SizeMove(0, 0, Width() - Height(), Height());
        m_up_bn->SizeMove(BN_X_POS, BORDER_THICK,
                          BN_X_POS + BN_WIDTH, BORDER_THICK + BNS_HEIGHT / 2);
        m_dn_bn->SizeMove(BN_X_POS, BORDER_THICK + m_up_bn->Height(),
                          BN_X_POS + BN_WIDTH, BORDER_THICK + m_up_bn->Height() + BNS_HEIGHT - m_up_bn->Height());
    }
   
    virtual void Disable(bool b = true)
    {
        Control::Disable(b);
        m_edit->Disable(b);
        m_up_bn->Disable(b);
        m_dn_bn->Disable(b);
    }
   
    void Incr() {SetValue(m_value + m_step_size);}  ///< increments the value of the control's text by StepSize(), up to at most MaxValue()
    void Decr() {SetValue(m_value - m_step_size);}  ///< decrements the value of the control's text by StepSize(), down to at least MinValue()
   
    /** sets the value of the control's text to \a value, locked to the range [MinValue(), MaxValue()]*/
    void SetValue(T value)
    {
        T old_value = m_value;
        if (value < m_min_value) {
            m_value = m_min_value;
        } else if (m_max_value < value) {
            m_value = m_max_value;
        } else {
            // if the value supplied does not equal a valid value
            if (std::abs(details::mod((value - m_min_value), m_step_size)) > std::numeric_limits<T>::epsilon()) {
                // find nearest valid value to the one supplied
                T closest_below = details::div((value - m_min_value), m_step_size) * m_step_size + m_min_value;
                T closest_above = closest_below + m_step_size;
                m_value = ((value - closest_below) < (closest_above - value) ? closest_below : closest_above);
            } else {
                m_value = value;
            }
        }
        *m_edit << m_value;
        if (m_value != old_value)
            m_value_changed_sig(m_value);
    }
    
    void           SetStepSize(T step)     {m_step_size = step;}   ///< sets the step size of the control to \a step
    void           SetMinValue(T value)    {m_min_value = value;}  ///< sets the minimum value of the control to \a value
    void           SetMaxValue(T value)    {m_max_value = value;}  ///< sets the maximum value of the control to \a value
   
    /** turns on or off the mode that allows the user to edit the value in the spinbox directly*/
    void AllowEdits(bool b = true)
    {
        DetachChildren();
        m_edit_connection.disconnect();
        if (m_editable = b) {
            AttachChild(m_edit);
            m_edit_connection = Connect(m_edit->FocusUpdateSignal(), &Spin::ValueUpdated, this);
        }
    }
   
    virtual void   SetColor(Clr c)               {Control::SetColor(c); m_up_bn->SetColor(c); m_dn_bn->SetColor(c);}
    void           SetTextColor(Clr c)           {m_edit->SetTextColor(c);}          ///< sets the text color
    void           SetInteriorColor(Clr c)       {m_edit->SetInteriorColor(c);}      ///< sets the interior color of the control
    void           SetHiliteColor(Clr c)         {m_edit->SetHiliteColor(c);}        ///< sets the color used to render hiliting around selected text
    void           SetSelectedTextColor(Clr c)   {m_edit->SetSelectedTextColor(c);}  ///< sets the color used to render selected text   
   
    ValueChangedSignalType& ValueChangedSignal() {return m_value_changed_sig;} ///< returns the value changed signal object for this DynamicGraphic
    //@}

    /** returns a std::string representing this Spin's exact type, including the type of its data, to aid with automatic
        XML saving and loading*/
    static string XMLTypeName()
    {
        string retval = "GG::Spin_";
        retval += typeid(ValueType).name();
        retval += "_";
        return retval;
    }
   
private:
    typedef T ValueType;

    enum {BORDER_THICK = 2, PIXEL_MARGIN = 5};
    enum Region {NONE, UP_BN, DN_BN};

    void Init(const shared_ptr<Font>& font, Clr color, Clr text_color, Clr interior, Uint32 flags)
    {
        Control::SetColor(color);
        m_edit = new Edit(0, 0, 1, 1, boost::lexical_cast<string>(m_value), font, CLR_ZERO, text_color, interior);
        if (!m_up_bn)
            m_up_bn = shared_ptr<Button>(new Button(0, 0, 1, 1, "+", font->FontName(), static_cast<int>(font->PointSize() * 0.75), color));
        if (!m_dn_bn)
            m_dn_bn = shared_ptr<Button>(new Button(0, 0, 1, 1, "-", font->FontName(), static_cast<int>(font->PointSize() * 0.75), color));
        if (m_editable) {
            AttachChild(m_edit);
            m_edit_connection = Connect(m_edit->FocusUpdateSignal(), &Spin::ValueUpdated, this);
        }
        SizeMove(UpperLeft(), LowerRight());
    }
   
    void ValueUpdated(const string& val_text)
    {
        T value;
        try {
            value = boost::lexical_cast<T>(val_text);
        } catch (boost::bad_lexical_cast) {
            SetValue(m_min_value);
            return;
        }
        SetValue(value);
    }
   
    T        m_value;
    T        m_step_size;
    T        m_min_value;
    T        m_max_value;
   
    bool     m_editable;
   
    Edit*                m_edit;
    shared_ptr<Button>   m_up_bn;
    shared_ptr<Button>   m_dn_bn;

    Region   m_initial_depressed_area;  ///< the part of the control originally under cursor in LButtonDown msg
    Region   m_depressed_area;          ///< the part of the control currently being "depressed" by held-down mouse button
   
    boost::signals::connection m_edit_connection;

    ValueChangedSignalType  m_value_changed_sig;
};

namespace details {
// provides a typesafe mod function
template <class T> inline 
T mod (T dividend, T divisor) {return dividend % divisor;}

// template specializations
template <> inline 
float mod<float> (float dividend, float divisor) {return std::fmod(dividend, divisor);}
template <> inline 
double mod<double> (double dividend, double divisor) {return std::fmod(dividend, divisor);}
template <> inline 
long double mod<long double> (long double dividend, long double divisor) {return std::fmod(dividend, divisor);}

// provides a typesafe div function
template <class T> inline 
T div (T dividend, T divisor) {return dividend / divisor;}

// template specializations
template <> inline 
float div<float> (float dividend, float divisor) {return std::floor(dividend / divisor);}
template <> inline 
double div<double> (double dividend, double divisor) {return std::floor(dividend / divisor);}
template <> inline 
long double div<long double> (long double dividend, long double divisor) {return std::floor(dividend / divisor);}
} // namespace details

} // namespace GG

#endif // _GGSpin_h_

